#!/usr/bin/env python3
"""Collect total energy, Fermi energy and dipole moment from E_* folders."""
import re
from pathlib import Path


def parse_field(folder: Path):
    incar = folder / "INCAR"
    if not incar.exists():
        return None
    for line in incar.read_text(errors="ignore").splitlines():
        if line.strip().upper().startswith("EFIELD") and "=" in line:
            return float(line.split("=", 1)[1].split("#", 1)[0].strip())
    return None


def parse_outcar(folder: Path):
    outcar = folder / "OUTCAR"
    if not outcar.exists():
        return None
    txt = outcar.read_text(errors="ignore")
    completed = "Voluntary context switches" in txt
    toten = None
    efermi = None
    dipz = None
    for line in txt.splitlines():
        if "free  energy   TOTEN" in line:
            m = re.search(r"TOTEN\s*=\s*([-+]?\d+\.\d+)", line)
            if m:
                toten = float(m.group(1))
        if "E-fermi" in line:
            m = re.search(r"E-fermi\s*:\s*([-+]?\d+\.\d+)", line)
            if m:
                efermi = float(m.group(1))
        if "dipolmoment" in line:
            vals = re.findall(r"[-+]?\d+\.\d+", line)
            if len(vals) >= 3:
                dipz = float(vals[2])
    return completed, toten, efermi, dipz


def main():
    rows = []
    for folder in sorted(Path(".").glob("E_*")):
        if not folder.is_dir():
            continue
        field = parse_field(folder)
        parsed = parse_outcar(folder)
        if parsed is None:
            rows.append((field, folder.name, None, None, None, False))
        else:
            completed, toten, efermi, dipz = parsed
            rows.append((field, folder.name, toten, efermi, dipz, completed))

    rows = sorted(rows, key=lambda x: (999 if x[0] is None else x[0]))
    with open("efield_summary.dat", "w") as f:
        f.write("# EFIELD_eV_per_A folder TOTEN_eV Efermi_eV dipole_z_eA completed\n")
        for r in rows:
            field, name, toten, efermi, dipz, completed = r
            f.write(f"{field if field is not None else float('nan'): .6f} {name:10s} ")
            f.write(f"{toten if toten is not None else float('nan'): .10f} ")
            f.write(f"{efermi if efermi is not None else float('nan'): .8f} ")
            f.write(f"{dipz if dipz is not None else float('nan'): .8f} ")
            f.write(f"{int(completed)}\n")
    print("Wrote efield_summary.dat")


if __name__ == "__main__":
    main()
