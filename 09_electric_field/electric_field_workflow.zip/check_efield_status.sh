#!/usr/bin/env bash
for d in E_*; do
  [ -d "$d" ] || continue
  echo "===== $d ====="
  if [ -f "$d/OUTCAR" ]; then
    grep "Voluntary context switches" "$d/OUTCAR" || echo "NOT FINISHED"
    grep "E-fermi" "$d/OUTCAR" | tail -1 || true
    grep "free  energy   TOTEN" "$d/OUTCAR" | tail -1 || true
    grep "dipolmoment" "$d/OUTCAR" | tail -1 || true
  else
    echo "OUTCAR missing"
  fi
done
